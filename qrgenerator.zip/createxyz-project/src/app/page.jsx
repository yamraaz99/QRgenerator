"use client";
import React from "react";

function MainComponent() {
  const [qrType, setQrType] = useState("url");
  const [qrData, setQrData] = useState("");
  const [size, setSize] = useState(300);
  const [isCopied, setIsCopied] = useState(false);
  const [qrImage, setQrImage] = useState(null);
  const [socialPlatform, setSocialPlatform] = useState("twitter");
  const [contactData, setContactData] = useState({
    name: "",
    phone: "",
    email: "",
    title: "",
    company: "",
    website: "",
    address: "",
    note: "",
  });
  const [socialData, setSocialData] = useState({
    platform: "twitter",
    username: "",
  });
  const handleCopy = () => {
    navigator.clipboard.writeText(qrData);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };
  const generateQRCode = async () => {
    if (!qrData) return;

    try {
      const url = `/integrations/qr-code/generatebasicbase64?data=${encodeURIComponent(
        qrData
      )}&size=${size}`;

      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to generate QR code");

      const imageData = await response.text();
      setQrImage(`data:image/png;base64,${imageData}`);
    } catch (error) {
      console.error("Error generating QR code:", error);
    }
  };
  const handleSocialMediaChange = (platform, username) => {
    if (!username) return;

    const socialUrls = {
      twitter: `https://twitter.com/${username}`,
      facebook: `https://facebook.com/${username}`,
      instagram: `https://instagram.com/${username}`,
      linkedin: `https://linkedin.com/in/${username}`,
      tiktok: `https://tiktok.com/@${username}`,
      youtube: `https://youtube.com/c/${username}`,
    };

    const newUrl = socialUrls[platform] || "";
    setQrData(newUrl);
  };
  const handleContactChange = (field, value) => {
    const updatedContact = {
      ...contactData,
      [field]: value,
    };
    setContactData(updatedContact);

    const vCard = [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `FN:${updatedContact.name || ""}`,
      `TEL;TYPE=CELL:${updatedContact.phone || ""}`,
      `EMAIL:${updatedContact.email || ""}`,
      `TITLE:${updatedContact.title || ""}`,
      `ORG:${updatedContact.company || ""}`,
      `URL:${updatedContact.website || ""}`,
      `ADR;TYPE=WORK:;;${updatedContact.address || ""}`,
      `NOTE:${updatedContact.note || ""}`,
      "END:VCARD",
    ].join("\n");

    setQrData(vCard);
  };

  useEffect(() => {
    if (qrData) {
      generateQRCode();
    }
  }, [qrData]);

  const qrTypes = [
    { id: "url", icon: "🌐", label: "Website URL" },
    { id: "text", icon: "📝", label: "Plain Text" },
    { id: "wifi", icon: "📶", label: "WiFi Network" },
    { id: "contact", icon: "👤", label: "Contact Card" },
    { id: "email", icon: "📧", label: "Email" },
    { id: "sms", icon: "💬", label: "SMS" },
    { id: "social", icon: "🔗", label: "Social Media" },
  ];

  const renderInputFields = () => {
    switch (qrType) {
      case "url":
        return (
          <input
            type="url"
            placeholder="Enter website URL"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg"
            name="url"
          />
        );
      case "text":
        return (
          <textarea
            placeholder="Enter your text message"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg h-32"
            name="text"
          />
        );
      case "wifi":
        return (
          <div className="space-y-4">
            <input
              type="text"
              name="ssid"
              placeholder="Network Name (SSID)"
              className="w-full p-3 border border-gray-300 rounded-lg"
              onChange={(e) => {
                const password =
                  document.querySelector('input[name="password"]')?.value || "";
                setQrData(`WIFI:S:${e.target.value};T:WPA;P:${password};;`);
              }}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="w-full p-3 border border-gray-300 rounded-lg"
              onChange={(e) => {
                const ssid =
                  document.querySelector('input[name="ssid"]')?.value || "";
                setQrData(`WIFI:S:${ssid};T:WPA;P:${e.target.value};;`);
              }}
            />
          </div>
        );
      case "contact":
        return (
          <div className="space-y-4 bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Contact Information
            </h3>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="John Doe"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.name}
                  onChange={(e) => handleContactChange("name", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Phone
                </label>
                <input
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.phone}
                  onChange={(e) => handleContactChange("phone", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="john@example.com"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.email}
                  onChange={(e) => handleContactChange("email", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Job Title
                </label>
                <input
                  type="text"
                  placeholder="Software Engineer"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.title}
                  onChange={(e) => handleContactChange("title", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Company
                </label>
                <input
                  type="text"
                  placeholder="Company Name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.company}
                  onChange={(e) =>
                    handleContactChange("company", e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Website
                </label>
                <input
                  type="url"
                  placeholder="https://example.com"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.website}
                  onChange={(e) =>
                    handleContactChange("website", e.target.value)
                  }
                />
              </div>

              <div className="col-span-2 space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Address
                </label>
                <textarea
                  placeholder="123 Main St, City, Country"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.address}
                  onChange={(e) =>
                    handleContactChange("address", e.target.value)
                  }
                  rows="2"
                />
              </div>

              <div className="col-span-2 space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Note
                </label>
                <textarea
                  placeholder="Additional information..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={contactData.note}
                  onChange={(e) => handleContactChange("note", e.target.value)}
                  rows="2"
                />
              </div>
            </div>
          </div>
        );
      case "email":
        return (
          <div className="space-y-4">
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              className="w-full p-3 border border-gray-300 rounded-lg"
              onChange={(e) => {
                const subject =
                  document.querySelector('input[name="subject"]')?.value || "";
                const body =
                  document.querySelector('textarea[name="body"]')?.value || "";
                setQrData(
                  `mailto:${e.target.value}?subject=${encodeURIComponent(
                    subject
                  )}&body=${encodeURIComponent(body)}`
                );
              }}
            />
            <input
              type="text"
              name="subject"
              placeholder="Subject"
              className="w-full p-3 border border-gray-300 rounded-lg"
              onChange={(e) => {
                const email =
                  document.querySelector('input[name="email"]')?.value || "";
                const body =
                  document.querySelector('textarea[name="body"]')?.value || "";
                setQrData(
                  `mailto:${email}?subject=${encodeURIComponent(
                    e.target.value
                  )}&body=${encodeURIComponent(body)}`
                );
              }}
            />
            <textarea
              name="body"
              placeholder="Email Body"
              className="w-full p-3 border border-gray-300 rounded-lg h-32"
              onChange={(e) => {
                const email =
                  document.querySelector('input[name="email"]')?.value || "";
                const subject =
                  document.querySelector('input[name="subject"]')?.value || "";
                setQrData(
                  `mailto:${email}?subject=${encodeURIComponent(
                    subject
                  )}&body=${encodeURIComponent(e.target.value)}`
                );
              }}
            />
          </div>
        );
      case "sms":
        return (
          <div className="space-y-4">
            <input
              type="tel"
              name="phone"
              placeholder="Phone Number"
              className="w-full p-3 border border-gray-300 rounded-lg"
              onChange={(e) => {
                const message =
                  document.querySelector('textarea[name="message"]')?.value ||
                  "";
                setQrData(
                  `sms:${e.target.value}:${encodeURIComponent(message)}`
                );
              }}
            />
            <textarea
              name="message"
              placeholder="Message"
              className="w-full p-3 border border-gray-300 rounded-lg h-32"
              onChange={(e) => {
                const phone =
                  document.querySelector('input[name="phone"]')?.value || "";
                setQrData(`sms:${phone}:${encodeURIComponent(e.target.value)}`);
              }}
            />
          </div>
        );
      case "social":
        return (
          <div className="space-y-4">
            <select
              value={socialData.platform}
              onChange={(e) => {
                setSocialData({ ...socialData, platform: e.target.value });
                handleSocialMediaChange(e.target.value, socialData.username);
              }}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="twitter">Twitter</option>
              <option value="facebook">Facebook</option>
              <option value="instagram">Instagram</option>
              <option value="linkedin">LinkedIn</option>
              <option value="tiktok">TikTok</option>
              <option value="youtube">YouTube</option>
            </select>

            <div className="relative">
              <span className="absolute left-3 top-3 text-gray-500">@</span>
              <input
                type="text"
                placeholder="username"
                className="w-full p-3 pl-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                value={socialData.username}
                onChange={(e) => {
                  setSocialData({ ...socialData, username: e.target.value });
                  handleSocialMediaChange(socialData.platform, e.target.value);
                }}
              />
            </div>
          </div>
        );
      default:
        return (
          <input
            type="text"
            name="data"
            placeholder="Enter data"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg"
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="flex-grow">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl font-bold mb-4">Free QR Code Generator</h1>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Create custom QR codes for your business, personal use, or
              marketing campaigns. No sign-up required, completely free!
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-12">
            {qrTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setQrType(type.id)}
                className={`p-4 rounded-lg transition-all ${
                  qrType === type.id
                    ? "bg-blue-600 text-white shadow-lg scale-105"
                    : "bg-white hover:bg-gray-50 shadow"
                }`}
              >
                <div className="text-2xl mb-2">{type.icon}</div>
                <div className="text-sm font-medium">{type.label}</div>
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-6">
                  <div className="space-y-6">{renderInputFields()}</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-6">Preview & Download</h2>

              <div className="bg-gray-50 rounded-lg p-8 flex items-center justify-center min-h-[400px]">
                {qrImage ? (
                  <img
                    src={qrImage}
                    alt="Generated QR Code"
                    className="max-w-full max-h-[400px]"
                  />
                ) : (
                  <div className="text-center text-gray-500">
                    <div className="text-4xl mb-2">👆</div>
                    <div>Fill in the details to generate your QR code</div>
                  </div>
                )}
              </div>

              {qrImage && (
                <div className="mt-6 space-y-4">
                  <div className="flex gap-4">
                    <a
                      href={qrImage}
                      download="qr-code.png"
                      className="flex-1 bg-blue-600 text-white text-center py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Download PNG
                    </a>
                    <button
                      onClick={handleCopy}
                      className="flex-1 bg-green-600 text-white text-center py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
                    >
                      {isCopied ? "Copied!" : "Copy Data"}
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 text-center">
                    High-quality downloads for both digital and print use
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-gray-800 text-white py-6 mt-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">
            © 2024 QR Code Generator. Made by Kuldeep Singh
          </p>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;