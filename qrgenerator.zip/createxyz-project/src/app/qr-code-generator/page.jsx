"use client";
import React from "react";

function MainComponent() {
  const [qrType, setQrType] = useState("url");
  const [qrData, setQrData] = useState("");
  const [size, setSize] = useState(300);
  const [foregroundColor, setForegroundColor] = useState("#000000");
  const [backgroundColor, setBackgroundColor] = useState("#FFFFFF");
  const [style, setStyle] = useState("square");
  const [logo, setLogo] = useState(null);
  const [isCopied, setIsCopied] = useState(false);
  const [qrImage, setQrImage] = useState(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(qrData);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const renderInputFields = () => {
    switch (qrType) {
      case "url":
        return (
          <input
            type="url"
            placeholder="Enter website URL"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg"
            name="url"
          />
        );
      case "text":
        return (
          <textarea
            placeholder="Enter your text message"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg h-32"
            name="text"
          />
        );
      case "wifi":
        return (
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Network Name (SSID)"
              className="w-full p-3 border border-gray-300 rounded-lg"
              name="ssid"
              onChange={(e) =>
                setQrData(
                  `WIFI:S:${e.target.value};T:WPA;P:${
                    document.querySelector('input[name="password"]').value
                  };;`
                )
              }
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full p-3 border border-gray-300 rounded-lg"
              name="password"
              onChange={(e) =>
                setQrData(
                  `WIFI:S:${
                    document.querySelector('input[name="ssid"]').value
                  };T:WPA;P:${e.target.value};;`
                )
              }
            />
          </div>
        );
      default:
        return (
          <input
            type="text"
            placeholder="Enter data"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg"
            name="data"
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <head>
        <title>Free QR Code Generator | Create Dynamic QR Codes</title>
        <meta
          name="description"
          content="Generate custom QR codes for URLs, text, WiFi, and more. Create professional QR codes with logos and custom designs."
        />
        <meta
          name="keywords"
          content="QR code generator, dynamic QR codes, custom QR codes, free QR maker"
        />
        <meta property="og:title" content="Free QR Code Generator" />
        <meta
          property="og:description"
          content="Create custom QR codes for your business or personal use"
        />
      </head>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-inter font-bold text-gray-900 dark:text-white mb-4">
            Free QR Code Generator
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Create custom QR codes for URLs, text, WiFi credentials, and more.
            Add your logo, choose colors, and download in multiple formats.
          </p>
        </div>

        <></>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-inter font-semibold text-gray-900 dark:text-white mb-4">
                Enter Your Details
              </h2>
              {renderInputFields()}
            </div>

            <></>
          </div>

          <div className="space-y-8">
            <></>
          </div>
        </div>

        <div className="mt-12">
          <DownloadShare
            qrImageData={qrImage}
            shareUrl={qrData}
            onCopy={handleCopy}
            isCopied={isCopied}
          />
        </div>
      </div>
    </div>
  );
}

export default MainComponent;