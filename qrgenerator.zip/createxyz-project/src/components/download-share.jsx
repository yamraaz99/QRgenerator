"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ qrImageData, shareUrl, onCopy, isCopied }) {
  const downloadFormats = [
    { id: "png", label: "PNG", icon: "fa-file-image" },
    { id: "svg", label: "SVG", icon: "fa-bezier-curve" },
    { id: "pdf", label: "PDF", icon: "fa-file-pdf" },
  ];

  const shareOptions = [
    {
      id: "whatsapp",
      label: "WhatsApp",
      icon: "fa-whatsapp",
      color: "bg-[#25D366]",
    },
    {
      id: "instagram",
      label: "Instagram",
      icon: "fa-instagram",
      color: "bg-[#E4405F]",
    },
    { id: "email", label: "Email", icon: "fa-envelope", color: "bg-[#EA4335]" },
  ];

  const handleDownload = (format) => {
    if (!qrImageData) return;
    const link = document.createElement("a");
    link.href = qrImageData;
    link.download = `qr-code.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = (platform) => {
    const shareData = {
      whatsapp: `https://wa.me/?text=${encodeURIComponent(shareUrl)}`,
      instagram: `https://instagram.com`,
      email: `mailto:?subject=QR Code&body=${encodeURIComponent(shareUrl)}`,
    };
    window.open(shareData[platform], "_blank");
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-inter font-medium text-gray-900 dark:text-white mb-4">
            Download QR Code
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {downloadFormats.map((format) => (
              <button
                key={format.id}
                onClick={() => handleDownload(format.id)}
                disabled={!qrImageData}
                className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <i
                  className={`fa-solid ${format.icon} mr-2 text-gray-500 dark:text-gray-400`}
                ></i>
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {format.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-inter font-medium text-gray-900 dark:text-white mb-4">
            Share QR Code
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {shareOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => handleShare(option.id)}
                className={`inline-flex items-center justify-center px-4 py-2 rounded-lg text-white ${option.color} hover:opacity-90 transition-opacity`}
              >
                <i className={`fa-brands ${option.icon} mr-2`}></i>
                <span className="text-sm">{option.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-inter font-medium text-gray-900 dark:text-white mb-4">
            Copy Link
          </h3>
          <button
            onClick={onCopy}
            className="inline-flex items-center justify-center w-full px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <i
              className={`fa-solid ${isCopied ? "fa-check" : "fa-copy"} mr-2`}
            ></i>
            <span className="text-sm">
              {isCopied ? "Copied!" : "Copy to Clipboard"}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const mockQrImage =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
  const mockShareUrl = "https://example.com/qr-code";

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
      <div className="space-y-8">
        <MainComponent
          qrImageData={mockQrImage}
          shareUrl={mockShareUrl}
          onCopy={handleCopy}
          isCopied={isCopied}
        />

        <MainComponent
          shareUrl={mockShareUrl}
          onCopy={handleCopy}
          isCopied={false}
        />
      </div>
    </div>
  );
});
}