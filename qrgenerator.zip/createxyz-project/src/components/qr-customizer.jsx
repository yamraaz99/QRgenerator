"use client";
import React from "react";

import { useUpload } from '../utilities/runtime-helpers'

export default function Index() {
  return (function MainComponent({
  onForegroundColorChange,
  onBackgroundColorChange,
  onLogoUpload,
  onStyleChange,
  onSizeChange,
  foregroundColor = "#000000",
  backgroundColor = "#FFFFFF",
  currentStyle = "square",
  size = 300,
  loading = false,
  error = null,
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [upload, { loading: uploadLoading }] = useUpload();

  const styles = [
    { id: "square", label: "Square", icon: "fa-solid fa-square" },
    { id: "rounded", label: "Rounded", icon: "fa-solid fa-circle" },
    { id: "dots", label: "Dots", icon: "fa-solid fa-ellipsis" },
  ];

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback(
    async (e) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);

      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith("image/")) {
        const { url, error } = await upload({ file });
        if (!error && url) {
          onLogoUpload?.(url);
        }
      }
    },
    [onLogoUpload, upload],
  );

  const handleFileSelect = useCallback(
    async (e) => {
      const file = e.target.files?.[0];
      if (file && file.type.startsWith("image/")) {
        const { url, error } = await upload({ file });
        if (!error && url) {
          onLogoUpload?.(url);
        }
      }
    },
    [onLogoUpload, upload],
  );

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="block text-sm font-inter font-medium text-gray-700 dark:text-gray-200">
              Foreground Color
            </label>
            <input
              type="color"
              value={foregroundColor}
              onChange={(e) => onForegroundColorChange?.(e.target.value)}
              className="h-10 w-full rounded border border-gray-300 dark:border-gray-600"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-inter font-medium text-gray-700 dark:text-gray-200">
              Background Color
            </label>
            <input
              type="color"
              value={backgroundColor}
              onChange={(e) => onBackgroundColorChange?.(e.target.value)}
              className="h-10 w-full rounded border border-gray-300 dark:border-gray-600"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-inter font-medium text-gray-700 dark:text-gray-200">
            Upload Logo
          </label>
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              isDragging
                ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20"
                : "border-gray-300 dark:border-gray-600"
            }`}
          >
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="logo-upload"
            />
            <label htmlFor="logo-upload" className="cursor-pointer">
              <i className="fa-solid fa-cloud-arrow-up text-2xl mb-2 text-gray-400"></i>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Drag and drop your logo or click to browse
              </p>
            </label>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-inter font-medium text-gray-700 dark:text-gray-200">
            QR Style
          </label>
          <div className="flex flex-wrap gap-2">
            {styles.map((style) => (
              <button
                key={style.id}
                onClick={() => onStyleChange?.(style.id)}
                className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                  currentStyle === style.id
                    ? "bg-blue-500 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200"
                }`}
              >
                <i className={style.icon}></i>
                <span>{style.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-inter font-medium text-gray-700 dark:text-gray-200">
            QR Size: {size}px
          </label>
          <input
            type="range"
            min="100"
            max="1000"
            value={size}
            onChange={(e) => onSizeChange?.(Number(e.target.value))}
            className="w-full"
          />
        </div>

        {error && <div className="text-red-500 text-sm">{error}</div>}

        {(loading || uploadLoading) && (
          <div className="text-blue-500 text-sm">Processing...</div>
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  const [foregroundColor, setForegroundColor] = useState("#000000");
  const [backgroundColor, setBackgroundColor] = useState("#FFFFFF");
  const [logo, setLogo] = useState(null);
  const [style, setStyle] = useState("square");
  const [size, setSize] = useState(300);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
      <MainComponent
        foregroundColor={foregroundColor}
        backgroundColor={backgroundColor}
        onForegroundColorChange={setForegroundColor}
        onBackgroundColorChange={setBackgroundColor}
        onLogoUpload={setLogo}
        onStyleChange={setStyle}
        onSizeChange={setSize}
        currentStyle={style}
        size={size}
      />
    </div>
  );
});
}