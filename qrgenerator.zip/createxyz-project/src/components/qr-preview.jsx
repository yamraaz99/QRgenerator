"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  qrCodeData,
  size = 300,
  foregroundColor = "#000000",
  backgroundColor = "#FFFFFF",
  logo,
  style = "square",
  loading = false,
  error = null,
}) {
  const [isScanning, setIsScanning] = useState(false);
  const [qrImage, setQrImage] = useState(null);

  useEffect(() => {
    const generateQR = async () => {
      if (!qrCodeData) return;

      try {
        const response = await fetch(
          `/integrations/qr-code/generatebasicbase64?data=${encodeURIComponent(qrCodeData)}&size=${size}`,
        );
        if (!response.ok) {
          throw new Error("Failed to generate QR code");
        }
        const base64Image = await response.text();
        setQrImage(base64Image);
      } catch (err) {
        console.error("Error generating QR code:", err);
      }
    };

    generateQR();
  }, [qrCodeData, size]);

  return (
    <div className="w-full max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <div className="relative">
        <div
          className={`aspect-square rounded-lg overflow-hidden ${
            style === "rounded"
              ? "rounded-2xl"
              : style === "dots"
                ? "rounded-full"
                : "rounded-lg"
          }`}
        >
          {loading ? (
            <div className="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-700">
              <i className="fa-solid fa-spinner fa-spin text-2xl text-gray-400"></i>
            </div>
          ) : qrImage ? (
            <div className="relative">
              <img
                src={`data:image/png;base64,${qrImage}`}
                alt="Generated QR Code"
                className="w-full h-full object-contain"
              />
              {logo && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1/4 h-1/4">
                  <img
                    src={logo}
                    alt="QR Code Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-700">
              <i className="fa-solid fa-qrcode text-4xl text-gray-400"></i>
            </div>
          )}
        </div>

        {isScanning && (
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0 bg-blue-500 opacity-20"></div>
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-blue-500 animate-qr-scan"></div>
          </div>
        )}
      </div>

      <div className="mt-4 flex justify-center">
        <button
          onClick={() => setIsScanning((prev) => !prev)}
          className="inline-flex items-center px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
        >
          <i className={`fa-solid fa-${isScanning ? "stop" : "play"} mr-2`}></i>
          {isScanning ? "Stop Preview" : "Show Scanning"}
        </button>
      </div>

      {error && (
        <div className="mt-4 text-red-500 text-sm text-center">{error}</div>
      )}
    </div>
  );

  return (
    <style jsx global>{`
      @keyframes qr-scan {
        0% {
          transform: translateY(0%);
        }
        100% {
          transform: translateY(100vh);
        }
      }
      .animate-qr-scan {
        animation: qr-scan 2s linear infinite;
      }
    `}</style>
  );
}

function StoryComponent() {
  const [qrData, setQrData] = useState("https://example.com");
  const [size, setSize] = useState(300);
  const [foregroundColor, setForegroundColor] = useState("#000000");
  const [backgroundColor, setBackgroundColor] = useState("#FFFFFF");
  const [style, setStyle] = useState("square");
  const [logo, setLogo] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-8">
      <div className="space-y-8">
        <MainComponent
          qrCodeData={qrData}
          size={size}
          foregroundColor={foregroundColor}
          backgroundColor={backgroundColor}
          style={style}
          logo={logo}
        />

        <MainComponent
          qrCodeData="https://create.xyz"
          size={200}
          style="rounded"
          loading={true}
        />

        <MainComponent
          qrCodeData="Error example"
          size={200}
          error="Failed to generate QR code"
        />
      </div>
    </div>
  );
});
}