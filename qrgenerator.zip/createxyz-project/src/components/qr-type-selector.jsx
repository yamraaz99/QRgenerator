"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ onTypeSelect }) {
  const qrTypes = [
    { id: "url", label: "Website URL", icon: "fa-solid fa-globe" },
    { id: "text", label: "Text/Message", icon: "fa-solid fa-message" },
    { id: "wifi", label: "WiFi Credentials", icon: "fa-solid fa-wifi" },
    { id: "contact", label: "Contact Info", icon: "fa-solid fa-address-card" },
    { id: "social", label: "Social Media", icon: "fa-solid fa-share-nodes" },
    { id: "email", label: "Email", icon: "fa-solid fa-envelope" },
    { id: "sms", label: "SMS", icon: "fa-solid fa-comment-sms" },
    { id: "payment", label: "Payment Link", icon: "fa-solid fa-credit-card" },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-inter font-bold text-gray-900 dark:text-white mb-6">
        Select QR Code Type
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {qrTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => onTypeSelect?.(type.id)}
            className="inline-flex items-center justify-center p-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-900 hover:text-white dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <div className="text-center">
              <i
                className={`${type.icon} text-2xl mb-3 text-gray-900 dark:text-white group-hover:text-white`}
              ></i>
              <p className="font-inter text-sm text-gray-900 dark:text-white">
                {type.label}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function StoryComponent() {
  const handleTypeSelect = (type) => {
    console.log("Selected type:", type);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-4">
      <MainComponent onTypeSelect={handleTypeSelect} />
    </div>
  );
});
}